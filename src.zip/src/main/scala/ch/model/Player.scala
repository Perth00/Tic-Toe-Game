package ch.model

import scalafx.beans.property.{IntegerProperty, ObjectProperty, StringProperty}
import scalikejdbc.DB
import scala.util.{Try, Success, Failure}
import scalikejdbc._
import java.time.LocalDate
import util.Database
import util.DateUtil._

class Player(val nameS: String) extends Database {
  var name = new StringProperty(nameS)
  var win = IntegerProperty(0)
  var lose = IntegerProperty(0)
  var date = ObjectProperty[LocalDate](LocalDate.now)

  def save(): Try[Int] = {
    if (!isExist) {
      Try(DB autoCommit { implicit session =>
        sql"""
          insert into PlayerRecord (name, win, lose, date) values
          (${name.value}, ${win.value}, ${lose.value}, ${date.value.asString})
        """.update.apply()
      })
    } else {
      Try(DB autoCommit { implicit session =>
        sql"""
          update PlayerRecord
          set
            win = ${win.value},
            lose = ${lose.value},
            date = ${date.value.asString}
          where name = ${name.value}
        """.update.apply()
      })
    }
  }

  def delete(): Try[Int] = {
    if (isExist) {
      Try(DB autoCommit { implicit session =>
        sql"""
          delete from PlayerRecord where name = ${name.value}
        """.update.apply()
      })
    } else
      throw new Exception("Player does not exist in Database")
  }

  def isExist: Boolean = {
    DB readOnly { implicit session =>
      sql"""
        select * from PlayerRecord where name = ${name.value}
      """.map(rs => rs.string("name")).single.apply()
    } match {
      case Some(_) => true
      case None => false
    }
  }

  def getWinCount: Int = {
    DB readOnly { implicit session =>
      sql"""
        select win from PlayerRecord where name = ${name.value}
      """.map(rs => rs.int("win")).single.apply()
    } match {
      case Some(winCount) => winCount
      case None => 0
    }
  }

  def getLoseCount: Int = {
    DB readOnly { implicit session =>
      sql"""
        select lose from PlayerRecord where name = ${name.value}
      """.map(rs => rs.int("lose")).single.apply()
    } match {
      case Some(loseCount) => loseCount
      case None => 0
    }
  }

  def getDate: String = {
    DB readOnly { implicit session =>
      sql"""
        select date from PlayerRecord where name = ${name.value}
      """.map(rs => rs.string("date")).single.apply()
    } match {
      case Some(dateValue) => dateValue
      case None => ""
    }
  }

  def addWinCount(): Try[Int] = {
    val currentWin = getWinCount
    win.value = currentWin + 1
    lose.value=getLoseCount
    date.value = getDate.parseLocalDate
    updatePlayerRecord()
  }

  def addLoseCount(): Try[Int] = {
    val currentLose = getLoseCount
    lose.value = currentLose + 1
    win.value = getWinCount
    date.value = getDate.parseLocalDate
    updatePlayerRecord()
  }

  def updateDate(newDate: LocalDate): Try[Int] = {
    date.value = newDate
    win.value = getWinCount
    lose.value = getLoseCount
    updatePlayerRecord()
  }
  private def updatePlayerRecord(): Try[Int] = {
    Try(DB autoCommit { implicit session =>
      sql"""
        update PlayerRecord
        set
          win = ${win.value},
          lose = ${lose.value},
          date = ${date.value.asString}
        where name = ${name.value}
      """.update.apply()
    })
  }
}

object Player extends Database {
  def apply(
             nameS: String,
             winS: Int,
             loseS: Int,
             dateS: String
           ): Player = {
    new Player(nameS) {
      win.value = winS
      lose.value = loseS
      date.value = dateS.parseLocalDate
    }
  }

  def initializeTable(): Unit = {
    DB autoCommit { implicit session =>
      sql"""
        create table PlayerRecord (
          id int not null GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),
          name varchar(64),
          win int,
          lose int,
          date varchar(64)
        )
      """.execute.apply()
    }
  }

  def getAllPlayers: List[Player] = {
    DB readOnly { implicit session =>
      sql"select * from PlayerRecord".map(rs => Player(
        rs.string("name"),
        rs.int("win"),
        rs.int("lose"),
        rs.string("date")
      )).list.apply()
    }
  }

  def findOrCreate(name: String): Player = {
    getPlayerByName(name) match {
      case Some(player) => player
      case None =>
        val newPlayer = new Player(name)
        newPlayer.save()
        newPlayer
    }
  }

  def getPlayerByName(name: String): Option[Player] = {
    DB readOnly { implicit session =>
      sql"select * from PlayerRecord where name = $name".map(rs => Player(
        rs.string("name"),
        rs.int("win"),
        rs.int("lose"),
        rs.string("date")
      )).single.apply()
    }
  }
}