package ch.view

import scalafx.stage.Stage
import scalafx.collections.ObservableBuffer
import scalafx.event.ActionEvent
import scalafx.scene.control.{TableColumn, TableView}
import scalafxml.core.macros.sfxml
import ch.model.Player
import scalafx.beans.property.{StringProperty, IntegerProperty, ObjectProperty}
import java.time.LocalDate
import util.DateUtil._
import ch.view.MainApp

@sfxml
class PlayerHistoryController(
                               private val playerHistoryTable: TableView[Player],
                               private val nameColumn: TableColumn[Player, String],
                               private val winColumn: TableColumn[Player, Number],
                               private val loseColumn: TableColumn[Player, Number],
                               private val dateColumn: TableColumn[Player, String]
                             ) {
  // initialize Table View display contents model
  playerHistoryTable.items = MainApp.PlayerDate

  // Initialize the table columns
  nameColumn.cellValueFactory = { cellData => cellData.value.name }
  winColumn.cellValueFactory = { cellData => ObjectProperty(cellData.value.win.value) }
  loseColumn.cellValueFactory = { cellData => ObjectProperty(cellData.value.lose.value) }
  dateColumn.cellValueFactory = { cellData => new StringProperty(cellData.value.date.value.toString) }

  var dialogStage: Stage = null
  var okClicked = false

  def closePlayerHistory(): Unit = {
    okClicked = true
    dialogStage.close()
  }


}
