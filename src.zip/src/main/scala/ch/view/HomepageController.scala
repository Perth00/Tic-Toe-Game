package ch.view

import ch.view.MainApp
import scalafx.event.ActionEvent
import scalafx.scene.control.{Alert, ButtonType}
import scalafx.scene.control.Alert.AlertType
import scalafxml.core.macros.sfxml
import ch.view.BoardController
import ch.view.MainApp.stage
import scalafx.application.JFXApp.Stage
import scalafx.application.Platform
import scalafx.stage.Stage

@sfxml
class HomepageController(){
  var dialogStage : Stage  = null
  var okClicked = false

  def getStart():Unit={
    // Logic to start the game
    alertInformationMessage()
    MainApp.showAddPlayerName()
  }
  def getStartWithBot():Unit={
    // Logic to start the game
    alertInformationMessage()
    MainApp.showAddPlayerWithBot()
  }
  // Function to close the game with a confirmation dialog.
  def closeTheGame(): Unit = {
    val alert = new Alert(AlertType.Confirmation) {
      initOwner(stage)
      title = "Exit Game"
      headerText = "Confirm Exit"
      contentText = "Are you sure you want to exit the game?"
    }
    // Apply custom CSS class to the dialog pane for styling
    val dialogPane = alert.dialogPane()
    dialogPane.getStylesheets.add(getClass.getResource("alertStyles.css").toExternalForm)
    dialogPane.getStyleClass.add("custom-alert")

    val result = alert.showAndWait()
    result match {
      case Some(ButtonType.OK) =>
        println("Closing the game")
        sys.exit(0)
      case _ =>
        println("Cancel exit")
    }
  }
  def openPlayPolicy(): Unit = {
    MainApp.showPlayPolicy()
  }
  def handleCloseButton():Unit={
    okClicked = true
    dialogStage.close()
  }
  def openPlayerHistory(): Unit = {
    MainApp.showPlayerHistory()
  }
  def alertInformationMessage(): Unit = {
    val alert = new Alert(AlertType.Information) {
      title = "Start Game"
      headerText = "Starting the Game!"
      contentText = "Game is starting..."
    }
    // Apply custom CSS class to the dialog pane for styling
    val dialogPane = alert.dialogPane()
    dialogPane.getStylesheets.add(getClass.getResource("alertStyles.css").toExternalForm)
    dialogPane.getStyleClass.add("custom-alert")
    alert.showAndWait()
  }
}



