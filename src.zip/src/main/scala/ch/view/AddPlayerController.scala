package ch.view

import scalafx.event.ActionEvent
import scalafx.scene.control.Alert
import scalafx.scene.control.Alert.AlertType
import scalafx.scene.control.TextField
import scalafx.stage.Stage
import scalafxml.core.macros.sfxml

import scala.reflect.internal.NoPhase.assignsFields.||

@sfxml
class AddPlayerController(private val player1: TextField, private val player2: TextField) {
  var dialogStage : Stage  = null
  var okClicked = false

  // Function to handle the action when confirming player names
  def confirmPlayerNames(action: ActionEvent): Unit = {
    if (isInputValid()) {
      val player1Name = player1.text.value.trim
      val player2Name = player2.text.value.trim
    if (player1Name.equalsIgnoreCase(player2Name)) {
        alertMessage("Please don't enter the same name")
        okClicked = false
      } else {
        okClicked = true
        dialogStage.close()
        MainApp.showBoard(player1Name, player2Name)
      }
    }
  }
  // Function to handle the action when confirming player names and ensure the name of bot
  def confirmPlayerNamesWithBot(action: ActionEvent): Unit = {
    if (isInputValidForBot()) {
      val player1Name = player1.text.value.trim
      if(player1Name.equalsIgnoreCase("Alphago")){
        alertMessage("Change one name, do not enter Alphago for both players, since it is for the bot")
        okClicked = false
      }else{
        okClicked = true
        dialogStage.close()
        MainApp.showBoard(player1Name, "Alphago")
      }
    }
  }

  def isInputValid(): Boolean = {
    var errorMessage = ""
    if (nullOrEmpty(player1.text.value))
      errorMessage += "• Please fill in Player 1's name.\n"

    if (nullOrEmpty(player2.text.value))
      errorMessage += "• Please fill in Player 2's name.\n"

    if (player1.text.value.equalsIgnoreCase("Alphago") || player2.text.value.equalsIgnoreCase("Alphago")) {
      errorMessage += "• Change one name, do not enter Alphago for both players, since it is for the bot\n"
    }

    if (errorMessage.isEmpty) {
      true // Return true if no errors
    } else {
      alertMessage(errorMessage)
      false // Return false to indicate input validation failed
    }
  }
  // Function to validate player names
  def isInputValidForBot(): Boolean = {
    var errorMessage = ""
    if (nullOrEmpty(player1.text.value))
      errorMessage += "• Please fill in Player 1's name.\n"

    if (errorMessage.isEmpty) {
      true // Return true if no errors
    } else {
      alertMessage(errorMessage)
      false // Return false to indicate input validation failed
    }
  }

  def alertMessage(message:String): Unit = {
    // Show the error message with custom styling
    val alert = new Alert(AlertType.Error) {
      initOwner(dialogStage)
      title = "Invalid Fields"
      headerText = "Please correct the following errors:"
      contentText = message
    }

    // Apply custom CSS class to the dialog pane for styling
    val dialogPane = alert.dialogPane()
    dialogPane.getStylesheets.add(getClass.getResource("alertStyles.css").toExternalForm)
    dialogPane.getStyleClass.add("custom-alert")

    // Show the alert dialog and wait for user response
    alert.showAndWait()
  }
  // Function to check if a string is null or empty
  private def nullOrEmpty(x: String): Boolean = x == null || x.trim.isEmpty

}
